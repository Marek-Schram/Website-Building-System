# Lessons Learned (symptom → root cause → fix)
- 2026-08-07 (seed): Secrets leak into client bundle if referenced outside a server route → keys in server-only .env.
- 2026-08-07: Feature detection is shared across parity + opportunities — keep the two detectors in sync (both detect reviews, ordering, booking, etc.) so they agree on what a site has.
- 2026-08-07: Opportunity reports must stay credible — a strong site should score near 0. Frame as help, not criticism.
